package assignment3;
import java.util.ArrayList;
public class PizzaShop {
	private static PizzaShop singlePizzaShop;
	int orderCounter;
	ArrayList<Order> orders;
	Oven pizzaOven;
	
	private PizzaShop()
	{
		orders = new ArrayList<>();
		pizzaOven = new Oven();
		orderCounter = 1;
	}
	public static PizzaShop getInstance() {
		if(singlePizzaShop == null)
			singlePizzaShop = new PizzaShop();
		return singlePizzaShop;
	}
	
	public void placeOrder(PizzaOrTopping p)
	{
		Order newOrder = new Order(orderCounter, singlePizzaShop.pizzaOven);
		orderCounter++;
		orders.add(newOrder);
		singlePizzaShop.getPizzaOven().registerObserver(newOrder);
		pizzaOven.addPizza(p);
	}

	public int getOrderCounter() {
		return orderCounter;
	}

	public Oven getPizzaOven() {
		return pizzaOven;
	}
	
	public String toString()
	{
		return pizzaOven.toString();
	}

}
