package assignment3;

public interface Observer {
	public void update(PizzaOrTopping pizza);
}
