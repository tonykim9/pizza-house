package assignment3;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;


public class Oven implements Subject{
	private PizzaOrTopping finishedPizza;
	private ArrayList<PizzaOrTopping> pizzas;
	private ArrayList<Observer> observers;
	
	public Oven()
	{
		pizzas = new ArrayList<>();
		observers = new ArrayList<>();
	}

	@Override
	public void registerObserver(Observer o) {
		observers.add(o);
	}

	@Override
	public void removeObserver(Observer o) {
		int i = observers.indexOf(o);
		if(i>=0)
		{
		observers.remove(i);
		}
	}

	@Override
	public void notifyObservers() {
		for(int i=0; i<observers.size();i++)
		{
			observers.get(i).update(finishedPizza);
		}
	}
	
	public void removePizza(PizzaOrTopping p)
	{
		int i = pizzas.indexOf(p);
		if(i>=0)
		{
		pizzas.remove(i);
		}
	}
	
	public void addPizza(PizzaOrTopping p)
	{
		pizzas.add(p);
		Timer pizzaTimer = new Timer();
		pizzaTimer.schedule(new TimerTask() {
			@Override
			public void run() {
				p.finish();	
				finishedPizza = p;	
				removePizza(p);	
				notifyObservers();	
			}
		},p.getCookingTime());
	}
	
	public String toString()
	{
		String pizzaList="";
		for(PizzaOrTopping p: pizzas)
		{
			pizzaList += p.getDescription();
		}
		return pizzaList;
	}

}
