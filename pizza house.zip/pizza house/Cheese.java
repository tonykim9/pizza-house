package assignment3;

public class Cheese extends Topping{

	private PizzaOrTopping pizzaOrTopping;
	double cost;
	int cookingTime;
	
	public Cheese(PizzaOrTopping pizzaOrTopping)
	{
		super(pizzaOrTopping.getOrderNum());
		this.pizzaOrTopping = pizzaOrTopping;
		cost = 1.00;
		cookingTime = 3000;
	}
	
	public String toString()
	{
		//topping name
		return "\tExtra Cheese\n";
	}

	@Override
	public String getDescription() {
		return pizzaOrTopping.getDescription()+toString();
	}

	@Override
	public long getCookingTime() {
		return pizzaOrTopping.getCookingTime()+cookingTime;
	}

	@Override
	public double cost() {
		return pizzaOrTopping.cost()+cost;
	}

}
