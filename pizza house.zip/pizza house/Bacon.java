package assignment3;

public class Bacon extends Topping{

	private PizzaOrTopping pizzaOrTopping;
	double cost;
	int cookingTime;
	
	public Bacon(PizzaOrTopping pizzaOrTopping)
	{
		super(pizzaOrTopping.getOrderNum());
		this.pizzaOrTopping = pizzaOrTopping;
		cost = 0.75;
		cookingTime = 2000;
	}
	
	public String toString()
	{
		//Toping name
		return "\tBacon\n";
	}

	@Override
	public String getDescription() {
		return pizzaOrTopping.getDescription()+toString();
	}

	@Override
	public long getCookingTime() {
		return pizzaOrTopping.getCookingTime()+cookingTime;
	}

	@Override
	public double cost() {
		return pizzaOrTopping.cost()+cost;
	}

}
