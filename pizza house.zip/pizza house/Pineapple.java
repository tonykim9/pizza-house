package assignment3;

public class Pineapple extends Topping{
	private PizzaOrTopping pizzaOrTopping;
	double cost;
	int cookingTime;
	
	public Pineapple(PizzaOrTopping pizzaOrTopping)
	{
		super(pizzaOrTopping.getOrderNum());
		this.pizzaOrTopping = pizzaOrTopping;
		cost = 1.00;
		cookingTime = 3500;
	}
	
	public String toString()
	{
		//topping name
		return "\tPineapples\n";
	}

	@Override
	public String getDescription() {
		return pizzaOrTopping.getDescription()+toString();
	}

	@Override
	public long getCookingTime() {
		return pizzaOrTopping.getCookingTime()+cookingTime;
	}

	@Override
	public double cost() {
		return pizzaOrTopping.cost()+cost;
	}

}
