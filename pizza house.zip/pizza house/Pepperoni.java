package assignment3;

public class Pepperoni extends Topping{
	private PizzaOrTopping pizzaOrTopping;
	double cost;
	int cookingTime;
	
	public Pepperoni(PizzaOrTopping pizzaOrTopping)
	{
		super(pizzaOrTopping.getOrderNum());
		this.pizzaOrTopping = pizzaOrTopping;
		cost = 2.00;
		cookingTime = 2500;
	}
	
	public String toString()
	{
		//topping name
		return "\tPepperoni\n";
	}

	@Override
	public String getDescription() {
		return pizzaOrTopping.getDescription()+toString();
	}

	@Override
	public long getCookingTime() {
		return pizzaOrTopping.getCookingTime()+cookingTime;
	}

	@Override
	public double cost() {
		return pizzaOrTopping.cost()+cost;
	}

}
